package com.example.instaclone.Messages.Notification;

public class MyResponse {
    public int success;
}
